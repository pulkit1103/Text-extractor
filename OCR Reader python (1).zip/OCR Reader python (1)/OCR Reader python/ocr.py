import easyocr
import cv2
import tkinter as tk
from tkinter import filedialog
import matplotlib.pyplot as plt
import numpy as np
import mysql.connector

# Initialize the EasyOCR Reader
reader = easyocr.Reader(['en'])  # 'en' for English

# Connect to MySQL Database
conn = mysql.connector.connect(
    host="localhost",
    user="karthik",         # Change this to your MySQL username
    password="123456",     # Change this to your MySQL password
    database="ocr_db"
)
cursor = conn.cursor()

# Create table if not exists
cursor.execute("""
    CREATE TABLE IF NOT EXISTS extracted_text (
        id INT AUTO_INCREMENT PRIMARY KEY,
        image_name VARCHAR(255),
        extracted_text TEXT
    )
""")
conn.commit()

# Function to browse and select image file
def browse_image():
    file_path = filedialog.askopenfilename(
        title="Select an Image",
        filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tiff")]
    )
    return file_path

# Function to capture image from webcam
def capture_image_from_camera():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Could not open webcam.")
        return None

    print("Press 's' to capture an image, 'q' to quit.")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to capture image.")
            break

        cv2.imshow("Camera Feed", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('s'):
            print("Image captured.")
            cv2.imwrite("captured_image.jpg", frame)
            cap.release()
            cv2.destroyAllWindows()
            return "captured_image.jpg"
        elif key == ord('q'):
            print("Exiting...")
            break

    cap.release()
    cv2.destroyAllWindows()
    return None

# Function to read text from image and save to MySQL database and text file
def ocr_from_image(image_path):
    img = cv2.imread(image_path)

    # Convert image to grayscale
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Adjust contrast and brightness (optional but useful for camera images)
    alpha = 1.5  # Increase contrast
    beta = 50    # Increase brightness
    img_contrast = cv2.convertScaleAbs(img_gray, alpha=alpha, beta=beta)

    # Adaptive Thresholding for better text extraction in varying lighting conditions
    img_threshold = cv2.adaptiveThreshold(
        img_contrast, 
        255, 
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
        cv2.THRESH_BINARY, 
        11, 
        2
    )

    # Perform OCR on the processed image
    result = reader.readtext(img_threshold)

    extracted_text = "\n".join([detection[1] for detection in result])

    # Insert extracted text into MySQL
    cursor.execute("INSERT INTO extracted_text (image_name, extracted_text) VALUES (%s, %s)", (image_path, extracted_text))
    conn.commit()
    print(f"Text has been saved to MySQL database.")

    # Save extracted text to a text file
    output_txt_file = image_path.split('.')[0] + '_extracted_text.txt'
    with open(output_txt_file, 'w', encoding='utf-8') as f:
        f.write(extracted_text)
    print(f"Extracted text has been saved to {output_txt_file}.")

    # Display results
    for detection in result:
        points = detection[0]
        points_int = [tuple(map(int, point)) for point in points]
        cv2.polylines(img, [np.array(points_int)], isClosed=True, color=(0, 255, 0), thickness=2)
        cv2.putText(img, detection[1], points_int[0], cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    plt.imshow(img_rgb)
    plt.axis('off')
    plt.show()

# Main function
def main():
    root = tk.Tk()
    root.withdraw()

    mode = input("Select mode: \n 1. Camera Mode \n 2. Browse Image Mode \n ")

    if mode == '1':
        image_path = capture_image_from_camera()
        if not image_path:
            print("No image captured. Exiting.")
            return
    elif mode == '2':
        image_path = browse_image()
        if not image_path:
            print("No image selected. Exiting.")
            return
    else:
        print("Invalid input. Exiting.")
        return

    ocr_from_image(image_path)

# Run the main function
if __name__ == "__main__":
    main()

# Close the database connection when script ends
cursor.close()
conn.close()
